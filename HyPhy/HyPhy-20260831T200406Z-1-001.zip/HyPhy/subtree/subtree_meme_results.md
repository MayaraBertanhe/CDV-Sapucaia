### For partition 1 these sites are significant at p <=0.1

|   Codon    | Partition  |   alpha    |non-syn rate (beta) distribution, rates : weights|    LRT     |Episodic selection detected?| # branches |         List of most common codon substitutions at this site          |
|:----------:|:----------:|:----------:|:-----------------------------------------------:|:----------:|:--------------------------:|:----------:|:---------------------------------------------------------------------:|
|    176     |     1      |   11.580   |            0.00/11150.39 : 0.81/0.19            |    6.311   |      Yes, p =  0.0192      |     1      |                          [1]TCC>CGT,tcC>tcG                           |
|    278     |     1      |    0.000   |            0.00/5874.48 : 0.80/0.20             |    4.320   |      Yes, p =  0.0536      |     1      |                              [1]Tcc>Gcc                               |
|    291     |     1      |    0.000   |             0.00/230.46 : 0.87/0.13             |    4.859   |      Yes, p =  0.0405      |     2      |                          [1]aCA>aTG,Aca>Tca                           |
|    306     |     1      |    0.000   |            0.00/4008.01 : 0.80/0.20             |    3.921   |      Yes, p =  0.0659      |     1      |                              [1]caT>caG                               |
|    527     |     1      |    0.000   |            0.00/2934.16 : 0.80/0.20             |    3.569   |      Yes, p =  0.0792      |     1      |                              [1]Ata>Gta                               |
|    604     |     1      |    0.012   |             0.01/232.45 : 0.28/0.72             |    4.470   |      Yes, p =  0.0496      |     1      |                              [1]cGT>cAA                               |

### ** Found _6_ sites under episodic diversifying positive selection at p <= 0.1**