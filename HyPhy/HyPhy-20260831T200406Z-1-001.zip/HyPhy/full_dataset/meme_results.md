### For partition 1 these sites are significant at p <=0.1

|   Codon    | Partition  |   alpha    |non-syn rate (beta) distribution, rates : weights|    LRT     |Episodic selection detected?| # branches |         List of most common codon substitutions at this site          |
|:----------:|:----------:|:----------:|:-----------------------------------------------:|:----------:|:--------------------------:|:----------:|:---------------------------------------------------------------------:|
|     25     |     1      |   15.379   |             0.00/223.58 : 0.68/0.32             |    3.174   |      Yes, p =  0.0974      |     3      |         [6]Tta>Cta|[1]TTa>CCa,TtA>CtG,tTa>tCa,ttA>ttC,ttA>ttG         |
|     49     |     1      |    0.000   |             0.00/29.20 : 0.63/0.37              |    4.277   |      Yes, p =  0.0548      |     5      |                              [5]Atc>Gtc                               |
|     60     |     1      |    0.000   |             0.00/941.45 : 0.80/0.20             |    4.330   |      Yes, p =  0.0533      |     2      |                          [1]Ttt>Ctt,ttT>ttG                           |
|    104     |     1      |    6.547   |            0.00/1132.22 : 0.87/0.13             |   10.880   |      Yes, p =  0.0019      |     1      |                 [2]ggG>ggA,Ggg>Ngg|[1]GGg>ACg,ggG>ggT                 |
|    105     |     1      |    5.535   |            3.44/19887.30 : 0.68/0.32            |    7.668   |      Yes, p =  0.0096      |     1      |                 [3]ttA>ttG|[1]Tta>Gta,tTA>tAT,tTa>tCa                 |
|    106     |     1      |    1.450   |             0.00/175.90 : 0.77/0.23             |    5.908   |      Yes, p =  0.0236      |     3      |                 [2]cGg>cAg|[1]cgG>cgA,cgG>cgC,CgG>TgC                 |
|    158     |     1      |    0.000   |              0.00/6.73 : 0.41/0.59              |    3.407   |      Yes, p =  0.0862      |     4      |                              [4]gGg>gAg                               |
|    161     |     1      |    0.000   |              0.00/7.96 : 0.01/0.99              |    4.613   |      Yes, p =  0.0460      |     6      |               [3]Aaa>Gaa|[2]aaA>aaC,aAa>aGa|[1]Gaa>Aaa                |
|    273     |     1      |    3.785   |             1.78/58.07 : 0.69/0.31              |    3.397   |      Yes, p =  0.0867      |     1      |         [4]Gtc>Atc|[1]aTc>aCc,GTc>ACc,gTc>gCc,gtC>gtA,gtC>gtT         |
|    291     |     1      |    0.000   |             0.00/88.07 : 0.88/0.12              |    9.817   |      Yes, p =  0.0032      |     5      |                 [2]aCA>aTG|[1]aCa>aTa,Aca>Gca,Aca>Tca                 |
|    313     |     1      |    0.000   |             0.00/11.30 : 0.31/0.69              |    3.718   |      Yes, p =  0.0733      |     5      |             [2]Gat>Aat,gAt>gGt|[1]Aat>Gat,GAt>ACt,Ggt>Agt             |
|    349     |     1      |   10.825   |             0.00/557.87 : 0.95/0.05             |    4.892   |      Yes, p =  0.0399      |     1      |                     [3]aaT>aaC|[1]aaC>aaT,AaT>GaA                     |
|    376     |     1      |    7.152   |             0.82/64.56 : 0.71/0.29              |    3.410   |      Yes, p =  0.0861      |     2      |[4]aAt>aTt|[3]aAt>aCt|[2]aAc>aCc|[1]Aac>Cac,AAc>GGc,aaT>aaC,aAt>aGt,...|
|    386     |     1      |    7.889   |             3.56/277.17 : 0.66/0.34             |    4.580   |      Yes, p =  0.0468      |     1      |           [4]Tcc>Acc|[2]Acc>Tcc,tcC>tcT|[1]acC>acA,TCC>CTT            |
|    480     |     1      |    0.000   |             0.00/294.74 : 0.80/0.20             |    3.269   |      Yes, p =  0.0927      |     2      |                              [2]Aca>Tca                               |
|    549     |     1      |    5.585   |             0.00/29.24 : 0.01/0.99              |    6.961   |      Yes, p =  0.0138      |     13     |                    [19]Tac>Cac|[2]Cac>Tac,taC>taT                     |
|    555     |     1      |    6.169   |            0.01/2811.26 : 0.85/0.15             |    3.265   |      Yes, p =  0.0929      |     1      |                         [3]acC>acT|[1]Acc>Gcc                         |
|    597     |     1      |    0.000   |              0.00/7.22 : 0.01/0.99              |    4.932   |      Yes, p =  0.0390      |     7      |               [4]cGt>cAt|[2]Cgt>Agt|[1]Cat>Tat,Cgt>Tgt                |
|    604     |     1      |    3.123   |             0.00/237.32 : 0.81/0.19             |    5.321   |      Yes, p =  0.0320      |     1      |                          [1]cGT>cAA,cgT>cgC                           |

### ** Found _19_ sites under episodic diversifying positive selection at p <= 0.1**